QueryNativeNytimes Demo

This demo performs two simple queries on nytimes local (single) native 
nytimes repository.


PREREQUISITES:
	- FillNativeNytimes demo must be executed
	- "native-storage.nytimes" must be located in "%baseDir%\data\repositories" 
	  (done during filling)
	
NOTES:
	- evaluation results can be seen in stdout and result/*.csv
