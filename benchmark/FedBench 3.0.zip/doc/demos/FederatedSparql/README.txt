FederatedSparql Demo

This demo performs two simple SPARQL queries against live endpoints
of dbpedia and nytimes.


PREREQUISITES:
	NONE
	
NOTES:
	- configuration parameter debugMode=true and showResults=true will show
	  the results
	- evaluation results can be seen in stdout and result/*.csv