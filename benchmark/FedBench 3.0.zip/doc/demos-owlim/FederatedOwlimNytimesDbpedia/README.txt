FederatedOwlimNytimes Demo

This demo performs two simple queries on nytimes and dbpedia data that resides
in a federation of two BigOWLim repositories 
nytimes repository.


PREREQUISITES:
	- FillOwlimNytimes demo must be executed
	- FillOwlimDbpedia demo must be executed
	- "owlim-storage.nytimes" must be located in "%baseDir%\data\repositories" 
	  (done during filling)
	  - "owlim-storage.dbpedia351" must be located in "%baseDir%\data\repositories" 
	  (done during filling)
	
NOTES:
	- evaluation results can be seen in stdout and result/*.csv
