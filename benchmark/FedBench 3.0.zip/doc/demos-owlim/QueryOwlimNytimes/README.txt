QueryOwlimNytimes Demo

This demo performs two simple queries on nytimes local (single) BigOWLim 
nytimes repository.


PREREQUISITES:
	- FillOwlimNytimes demo must be executed
	- "owlim-storage.nytimes" must be located in "%baseDir%\data\repositories" 
	  (done during filling)
	
NOTES:
	- evaluation results can be seen in stdout and result/*.csv
