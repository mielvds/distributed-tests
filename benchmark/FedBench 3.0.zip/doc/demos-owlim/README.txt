Demos for BigOWLim

These demos require the commercial BigOWLim library. If you have a licensed
version of this library, you can execute these demos as well. We built our
extension against BigOWLim 3.3

The library must be placed into the directory lib/owlim and the demos should
work out-of-the-box.