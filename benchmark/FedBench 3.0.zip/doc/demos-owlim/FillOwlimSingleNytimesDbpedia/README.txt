FillOwlimSingleNytimesDbpedia Demo

This demo fills a BigOWLim sesame store with parts of DBpedia and nytimes rdf data.


PREREQUISITES:
	DBpedia rdf datasets (part) must be downloaded and! unzipped to "%baseDir%\data\rdf\dbpedia351\":
	
	Ontology Infobox Types: http://downloads.dbpedia.org/3.5.1/en/instance_types_en.nt.bz2
	Ontology Infobox Properties: http://downloads.dbpedia.org/3.5.1/en/mappingbased_properties_en.nt.bz2
	
	Nytimes rdf datasets must be downloaded to "%baseDir%\data\rdf\nytimes\":
	
	Locations: http://data.nytimes.com/locations.rdf
	Organizations: http://data.nytimes.com/organizations.rdf
	People: http://data.nytimes.com/people.rdf
	
NOTES:
    - data sets are rather huge, hence filling takes quite some time!!!
	- evaluation results can be seen in stdout and result/*.csv
	- note: for filling config property "fill" must be set to true
	- no queries are evaluated for fill mode
	- filling of local repositories must be done only once per type