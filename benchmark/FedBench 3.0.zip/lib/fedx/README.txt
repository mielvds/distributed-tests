ReadMe

FedBench works with FedX > 2.0. Please download the corresponding binaries from
http://www.fluidops.com/fedx